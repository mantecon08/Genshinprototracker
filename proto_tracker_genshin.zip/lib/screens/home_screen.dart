
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ProtoTracker Genshin'),
      ),
      body: Center(
        child: Text('Bienvenido a tu tracker de protogemas y personajes.'),
      ),
    );
  }
}
